package com.kingdaddy606.viralradar.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.radarStore by preferencesDataStore("radar_settings")
class SettingsStore(private val context: Context) {
    private val endpointKey=stringPreferencesKey("worker_endpoint")
    private val autoScanKey=stringPreferencesKey("auto_scan")
    val endpoint=context.radarStore.data.map { it[endpointKey] ?: "" }
    val autoScan=context.radarStore.data.map { it[autoScanKey] ?: "Off" }
    suspend fun setEndpoint(value: String) { require(value.isBlank() || value.startsWith("https://")); context.radarStore.edit { it[endpointKey]=value.trim() } }
    suspend fun setAutoScan(value: String) { require(value in listOf("Off","Every 6 hours","Every 12 hours","Daily")); context.radarStore.edit { it[autoScanKey]=value } }
}
