package com.kingdaddy606.viralradar.data

import retrofit2.http.*
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.squareup.moshi.Moshi
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

interface RadarApi {
    @POST("api/scan") suspend fun scan(@Body request: ScanRequest): DiscoveryResponse
    @GET("api/discoveries") suspend fun discoveries(@Query("limit") limit: Int = 30): DiscoveryResponse
    @GET("api/videos/{id}") suspend fun video(@Path("id") id: String): Map<String, Any?>
    @GET("api/channels/{id}") suspend fun channel(@Path("id") id: String): Map<String, Any?>
    @GET("api/videos/{id}/history") suspend fun observations(@Path("id") id: String): Map<String, Any?>
    @POST("api/videos/{id}/refresh") suspend fun refresh(@Path("id") id: String): Map<String, Any?>
    @GET("api/quota") suspend fun quota(): Map<String, Any?>
    @GET("api/health") suspend fun health(): Map<String, Any?>
    companion object {
        fun create(baseUrl: String): RadarApi {
            require(baseUrl.startsWith("https://")) { "Use an HTTPS Worker URL." }
            val client=OkHttpClient.Builder().connectTimeout(15,TimeUnit.SECONDS).readTimeout(30,TimeUnit.SECONDS).build()
            return Retrofit.Builder().baseUrl(baseUrl.trimEnd('/')+"/").client(client).addConverterFactory(MoshiConverterFactory.create(Moshi.Builder().add(KotlinJsonAdapterFactory()).build())).build().create(RadarApi::class.java)
        }
    }
}
