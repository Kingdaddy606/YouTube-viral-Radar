package com.kingdaddy606.viralradar

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.delay
import androidx.work.*
import java.util.concurrent.TimeUnit
import com.kingdaddy606.viralradar.data.*
import coil.compose.AsyncImage
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF151A26)
private val Panel2 = Color(0xFF1C2433)
private val Red = Color(0xFFFF4057)
private val Gold = Color(0xFFFFC94A)
private val Mint = Color(0xFF65E0B8)
private val Muted = Color(0xFF9AA6B8)
private val White = Color(0xFFF4F6FA)
private val niches = listOf("All niches", "Education", "Technology", "Finance", "Business", "Entertainment", "Gaming", "Documentary", "History", "Science", "Motivation", "Storytelling", "Animation", "News", "Sports", "Music", "Travel", "Lifestyle", "Food", "Other")
private val fmt = NumberFormat.getNumberInstance(Locale.US)
private fun n(v: Long?): String = if (v == null) "Hidden" else fmt.format(v)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = RadarDatabase.get(this)
        val settings = SettingsStore(this)
        lifecycleScope.launch {
            val dao = db.dao()
            val cache = withContext(Dispatchers.IO) { dao.cached() }
            val saved = withContext(Dispatchers.IO) { dao.saved() }
            val history = withContext(Dispatchers.IO) { dao.scanHistory() }
            val discoveries = withContext(Dispatchers.IO) { dao.discoveryRecords() }
            setContent { RadarApp(dao, settings, cache, saved, history, discoveries) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun RadarApp(dao: RadarDao, settings: SettingsStore, initialCache: List<CachedVideo>, initialSaved: List<SavedItem>, initialHistory: List<ScanRecord>, initialDiscoveries: List<DiscoveryRecord>) {
    val scope = rememberCoroutineScope()
    val moshi = remember { Moshi.Builder().add(KotlinJsonAdapterFactory()).build() }
    val videoAdapter = remember { moshi.adapter(VideoDto::class.java) }
    val endpoint by settings.endpoint.collectAsState(initial = "")
    val autoScan by settings.autoScan.collectAsState(initial = "Off")
    val launchDiscovery by settings.launchDiscovery.collectAsState(initial = "true")
    val randomSelection by settings.randomSelection.collectAsState(initial = "true")
    val rapidGrowth by settings.rapidGrowth.collectAsState(initial = "true")
    val minimumViewsSetting by settings.minimumViews.collectAsState(initial = "100000")
    val subscriberCeilingSetting by settings.subscriberCeiling.collectAsState(initial = "10000")
    val ageFilterEnabled by settings.ageFilterEnabled.collectAsState(initial = "false")
    val videoAgeSetting by settings.videoAge.collectAsState(initial = "7 days")
    val videoLengthSetting by settings.videoLength.collectAsState(initial = "Long-form (over 5 minutes)")
    var showLaunchSplash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1300); showLaunchSplash = false }
    var tab by remember { mutableIntStateOf(0) }
    var cache by remember { mutableStateOf(initialCache) }
    var saved by remember { mutableStateOf(initialSaved) }
    var videos by remember { mutableStateOf(initialCache.mapNotNull { runCatching { videoAdapter.fromJson(it.payload) }.getOrNull() }) }
    var selectedVideo by remember { mutableStateOf<VideoDto?>(null) }
    var selectedChannel by remember { mutableStateOf<Map<String,Any?>?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var scanJob by remember { mutableStateOf<Job?>(null) }
    var scanMessage by remember { mutableStateOf("No scan has been run in this installation.") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var quotaMessage by remember { mutableStateOf("Quota estimate unavailable until backend is connected.") }
    var lastScan by remember { mutableStateOf(initialHistory.firstOrNull { it.status == "success" }?.startedAt) }
    var historyCount by remember { mutableIntStateOf(initialHistory.size) }
    var scanHistory by remember { mutableStateOf(initialHistory) }
    var discoveryRecords by remember { mutableStateOf(initialDiscoveries) }
    var endpointDraft by remember(endpoint) { mutableStateOf(endpoint) }
    var maxResults by remember { mutableIntStateOf(25) }
    var nextPageToken by remember { mutableStateOf<String?>(null) }

    fun reloadLocal() {
        scope.launch {
            val pair = withContext(Dispatchers.IO) { dao.cached() to dao.saved() }
            cache = pair.first; saved = pair.second
            videos = pair.first.mapNotNull { runCatching { videoAdapter.fromJson(it.payload) }.getOrNull() }
        }
    }
    fun apiOrNull(): RadarApi? = runCatching { if (endpoint.isBlank()) null else RadarApi.create(endpoint) }.getOrNull()
    suspend fun syncDiscoveriesFromWorker() {
        val api = apiOrNull() ?: return
        val remoteItems = withContext(Dispatchers.IO) { api.discoveries(100).items }
        withContext(Dispatchers.IO) {
            remoteItems.forEach { v ->
                val payload = videoAdapter.toJson(v)
                dao.addDiscovery(DiscoveryRecord(v.videoId, System.currentTimeMillis(), v.viewCount, v.subscriberCount, v.score?.score, payload, payload))
                dao.updateDiscovery(v.videoId, payload)
                dao.cache(CachedVideo(v.videoId, v.title, payload))
            }
        }
        val latestCache = withContext(Dispatchers.IO) { dao.cached() }
        cache = latestCache
        videos = latestCache.mapNotNull { runCatching { videoAdapter.fromJson(it.payload) }.getOrNull() }
        discoveryRecords = withContext(Dispatchers.IO) { dao.discoveryRecords() }
    }
    LaunchedEffect(tab, endpoint) {
        if (tab == 1 && endpoint.isNotBlank()) {
            try { syncDiscoveriesFromWorker() }
            catch (e: Exception) { errorMessage = e.message ?: "Could not refresh discoveries from the Worker." }
        }
    }
    fun openChannelProfile(channelId: String) {
        val api = apiOrNull() ?: run { errorMessage = "Connect the Worker to load channel intelligence."; return }
        scope.launch { try { selectedChannel = withContext(Dispatchers.IO) { api.channel(channelId) } } catch (e: Exception) { errorMessage = e.message ?: "Channel profile unavailable." } }
    }
    fun saveChannel(v: VideoDto) {
        val id = v.channelId ?: return
        scope.launch(Dispatchers.IO) { dao.save(SavedItem(id,"channel",v.channelTitle ?: id,null)); withContext(Dispatchers.Main) { saved = dao.saved() } }
    }
    fun saveVideo(v: VideoDto) {
        scope.launch(Dispatchers.IO) {
            dao.save(SavedItem(v.videoId, "video", v.title, v.thumbnailUrl))
            withContext(Dispatchers.Main) { saved = dao.saved() }
        }
    }
    fun runScan(query: String, niche: String, age: String, subCeiling: String, minViews: String, format: String, pageToken: String? = null) {
        val api = apiOrNull()
        if (api == null) { errorMessage = "Add a valid HTTPS Cloudflare Worker URL in Settings before scanning."; return }
        if (query.isBlank() && niche == "All niches") { errorMessage = "Enter a topic or choose a niche to scan."; return }
        if (subCeiling.isNotBlank() && parseMetric(subCeiling) == null) { errorMessage = "Subscriber ceiling must be a valid number (or use a preset)."; return }
        if (minViews.isNotBlank() && parseMetric(minViews) == null) { errorMessage = "Minimum views must be a valid number (or use a preset)."; return }
        if (age.isNotBlank() && parseAgeHours(age) == null) { errorMessage = "Video age must be a valid number of days or hours."; return }
        scanning = true; errorMessage = null; scanMessage = "Searching YouTube through your configured Worker…"
        scanJob = scope.launch {
            try {
                val response = withContext(Dispatchers.IO) { api.scan(ScanRequest(query = if (query.isNotBlank()) query else niche, maxResults = maxResults, order = "viewCount", niche = niche, age = age, subscriberCeiling = subCeiling, minimumViews = minViews, channelFormat = format, pageToken = pageToken)) }
                val filtered = applyClientFilters(response.items, age, subCeiling, minViews, format)
                nextPageToken = response.nextPageToken
                withContext(Dispatchers.IO) {
                    filtered.forEach { v -> val payload=videoAdapter.toJson(v); dao.addDiscovery(DiscoveryRecord(v.videoId,System.currentTimeMillis(),v.viewCount,v.subscriberCount,v.score?.score,payload,payload)); dao.updateDiscovery(v.videoId,payload); dao.cache(CachedVideo(v.videoId, v.title, payload)); dao.observe(Observation(videoId = v.videoId, views = v.viewCount ?: 0L)) }
                }
                // Refresh from the server after the scan so Discover never relies only on stale phone cache.
                syncDiscoveriesFromWorker()
                reloadLocal(); lastScan = System.currentTimeMillis(); historyCount += 1
                withContext(Dispatchers.IO) { dao.addScan(ScanRecord(query = if (query.isNotBlank()) query else niche, resultCount = filtered.size, status = "success", message = "Scan complete", estimatedUnits = response.quota?.searchUnitsEstimated)) }
                scanHistory = withContext(Dispatchers.IO) { dao.scanHistory() }
                discoveryRecords = withContext(Dispatchers.IO) { dao.discoveryRecords() }
                quotaMessage = response.quota?.note ?: "Quota estimate returned by Worker; verify actual usage in Google Cloud Console."
                scanMessage = "Scan complete · ${filtered.size} returned videos · ${filtered.mapNotNull { it.channelId }.distinct().size} channels. Search results are a sample, not all YouTube."
            } catch (e: CancellationException) {
                scanMessage = "Scan cancelled. Previously cached discoveries were kept."
                withContext(NonCancellable + Dispatchers.IO) { dao.addScan(ScanRecord(query = if (query.isNotBlank()) query else niche, resultCount = 0, status = "cancelled", message = "Scan cancelled by user")); dao.scanHistory() }.also { scanHistory = it }
                throw e
            } catch (e: Exception) {
                errorMessage = e.message ?: "Scan failed. Check connection, Worker logs and API quota."; scanMessage = "Last scan failed. Cached discoveries remain available."
                withContext(Dispatchers.IO) { dao.addScan(ScanRecord(query = if (query.isNotBlank()) query else niche, resultCount = 0, status = "failed", message = errorMessage ?: "Scan failed")) }
                scanHistory = withContext(Dispatchers.IO) { dao.scanHistory() }
            } finally { scanning = false }
        }
    }

    LaunchedEffect(endpoint, launchDiscovery) {
        if (launchDiscovery == "true" && endpoint.startsWith("https://") && !scanning) {
            runScan(if (randomSelection == "true") listOf("viral", "trending", "breakout", "popular documentary", "technology", "comedy", "education", "storytelling", "gaming").random() else "viral", "All niches", if (ageFilterEnabled == "true") videoAgeSetting else "", "Under ${subscriberCeilingSetting}", minimumViewsSetting, "All formats", null)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, secondary = Gold, background = Bg, surface = Panel, onBackground = White, onSurface = White)) {
        if (showLaunchSplash) {
            Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Image(painterResource(id = R.drawable.app_icon), contentDescription = "YouTube Viral Radar icon", modifier = Modifier.size(132.dp))
                    Text("YOUTUBE VIRAL RADAR", color = White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                    Text("Spot momentum before it goes mainstream", color = Gold, fontSize = 11.sp)
                }
            }
        } else Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Muted) {
                val names = listOf("Home", "Discover", "Growth", "Saved", "History", "Settings")
                val icons = listOf(Icons.Default.Dashboard, Icons.Default.Explore, Icons.Default.TrendingUp, Icons.Default.Bookmark, Icons.Default.History, Icons.Default.Settings)
                names.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 9.sp, maxLines = 1) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = White, indicatorColor = Panel2, unselectedIconColor = Muted, unselectedTextColor = Muted)) }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("YOUTUBE  /  INTELLIGENCE", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                        Text(listOf("Dashboard", "Discover", "Growth Tracker", "Watchlist", "History", "Settings")[tab], color = White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Surface(color = if (endpoint.isBlank()) Color(0xFF392B1B) else Color(0xFF16362F), shape = CircleShape) {
                        Text(if (endpoint.isBlank()) "● OFFLINE" else "● WORKER SET", Modifier.padding(horizontal = 11.dp, vertical = 8.dp), color = if (endpoint.isBlank()) Gold else Mint, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                when (tab) {
                    0 -> DashboardScreen(videos, saved, scanMessage, lastScan, quotaMessage, scanHistory.size, discoveryRecords, dao, { tab = 1 }, { selectedVideo = it })
                    1 -> DiscoverScreen(scanning, maxResults, { maxResults = it }, nextPageToken, ::runScan, { scanJob?.cancel() }, videos, dao, { selectedVideo = it }, ::saveVideo, scanMessage, errorMessage, randomSelection, rapidGrowth, minimumViewsSetting, subscriberCeilingSetting, videoLengthSetting, ageFilterEnabled, videoAgeSetting)
                    2 -> GrowthScreen(saved, dao, apiOrNull(), { errorMessage = it })
                    3 -> WatchlistScreen(saved, videos, { id -> scope.launch(Dispatchers.IO) { dao.unsave(id); withContext(Dispatchers.Main) { reloadLocal() } } }, { selectedVideo = it }, { id -> openChannelProfile(id) }, { id -> scope.launch(Dispatchers.IO) { val v = videos.firstOrNull { it.videoId == id }; if (v != null) dao.observe(Observation(videoId = id, views = v.viewCount ?: 0L)); withContext(Dispatchers.Main) { reloadLocal() } } })
                    4 -> HistoryScreen(cache, videos, scanHistory, discoveryRecords, { selectedVideo = it }, { reloadLocal() })
                    else -> SettingsScreen(
                        endpointDraft, { endpointDraft = it }, { value -> scope.launch { runCatching { settings.setEndpoint(value); scheduleRadarScan(autoScan, value); errorMessage = null }.onFailure { errorMessage = it.message } } },
                        autoScan, { value -> scope.launch { settings.setAutoScan(value); scheduleRadarScan(value, endpoint) } },
                        quotaMessage, apiOrNull(), { quotaMessage = it },
                        launchDiscovery == "true", { v -> scope.launch { settings.setLaunchDiscovery(v) } },
                        randomSelection == "true", { v -> scope.launch { settings.setRandomSelection(v) } },
                        rapidGrowth == "true", { v -> scope.launch { settings.setRapidGrowth(v) } },
                        minimumViewsSetting, { v -> scope.launch { runCatching { settings.setMinimumViews(v) }.onFailure { errorMessage = "Enter a whole-number minimum view count." } } },
                        subscriberCeilingSetting, { v -> scope.launch { runCatching { settings.setSubscriberCeiling(v) }.onFailure { errorMessage = "Enter a whole-number subscriber limit." } } },
                        ageFilterEnabled == "true", { v -> scope.launch { settings.setAgeFilterEnabled(v) } },
                        videoAgeSetting, { v -> scope.launch { settings.setVideoAge(v) } },
                        videoLengthSetting, { v -> scope.launch { settings.setVideoLength(v) } }
                    )
                }
            }
        }
        if (selectedVideo != null) VideoDetailDialog(selectedVideo!!, saved.any { it.id == selectedVideo!!.videoId }, { saveVideo(selectedVideo!!) }, { saveChannel(selectedVideo!!) }, { id -> openChannelProfile(id) }, { selectedVideo = null })
        selectedChannel?.let { ChannelDetailDialog(it) { selectedChannel = null } }
        errorMessage?.let { msg -> AlertDialog(onDismissRequest = { errorMessage = null }, title = { Text("Radar notice") }, text = { Text(msg) }, confirmButton = { TextButton(onClick = { errorMessage = null }) { Text("OK") } }, containerColor = Panel) }
    }
}

@Composable private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(13.dp), content = content) }
@Composable private fun Block(content: @Composable ColumnScope.() -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) } }
@Composable private fun RowScope.Metric(label: String, value: String, tint: Color = White) { Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) { Column(Modifier.padding(12.dp)) { Text(value, color = tint, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp); Text(label, color = Muted, fontSize = 10.sp) } } }
@Composable private fun SectionTitle(title: String, sub: String? = null) { Column { Text(title, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold); if (sub != null) Text(sub, color = Muted, fontSize = 12.sp) } }

@Composable private fun DashboardScreen(videos: List<VideoDto>, saved: List<SavedItem>, status: String, lastScan: Long?, quota: String, scanCount: Int, discoveries: List<DiscoveryRecord>, dao: RadarDao, discover: () -> Unit, open: (VideoDto) -> Unit) {
    var acceleratingCount by remember { mutableIntStateOf(0) }
    var measuredGrowth by remember { mutableStateOf<Map<String,Long>>(emptyMap()) }
    LaunchedEffect(videos) { val values = withContext(Dispatchers.IO) { videos.associate { v -> val obs=dao.observations(v.videoId); val delta=if(obs.size>=2) obs.last().views-obs.first().views else Long.MIN_VALUE; val accelerating=if(obs.size>=3) { val firstRate=(obs[1].views-obs[0].views).toDouble()/(obs[1].observedAt-obs[0].observedAt).coerceAtLeast(1L); val lastRate=(obs.last().views-obs[obs.size-2].views).toDouble()/(obs.last().observedAt-obs[obs.size-2].observedAt).coerceAtLeast(1L); lastRate > firstRate } else false; v.videoId to (delta to accelerating) } }; measuredGrowth=values.mapValues { it.value.first }; acceleratingCount=values.values.count { it.second } }
    ScreenColumn {
        Block {
            Text("EARLY SIGNAL RADAR", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text("Spot momentum before it goes mainstream.", color = White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            Text("Discover videos outperforming the size of their channels. All figures below come from your saved API results and local observations.", color = Muted, fontSize = 12.sp)
            Button(onClick = discover, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Icon(Icons.Default.Explore, null); Spacer(Modifier.width(8.dp)); Text("Start a discovery scan") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { Metric("Videos cached", videos.size.toString()); Metric("High potential", videos.count { (it.score?.score ?: 0) >= 70 }.toString(), Gold); Metric("Saved", saved.size.toString(), Mint) }
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { Metric("Channels found", videos.mapNotNull { it.channelId }.distinct().size.toString()); Metric("Likely faceless", videos.count { it.faceless?.label?.contains("faceless", true) == true }.toString()); Metric("Accelerating", acceleratingCount.toString(), Gold) }
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { Metric("Scan history", scanCount.toString()); Metric("Saved items", saved.size.toString(), Mint); Metric("Top score", (videos.maxOfOrNull { it.score?.score ?: 0 } ?: 0).toString(), Gold) }
        Block {
            SectionTitle("Latest scan", "Status from your most recent scan attempt")
            Text(status, color = Muted, fontSize = 12.sp)
            Text(if (lastScan == null) "No successful scan recorded on this device" else "Last successful scan: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(lastScan))}", color = Mint, fontSize = 11.sp)
            Divider(color = Panel2)
            Text("Quota", color = White, fontWeight = FontWeight.Bold)
            Text(quota, color = Muted, fontSize = 11.sp)
        }
        Block { SectionTitle("How the viral score works"); Text("Views/subscriber ratio · up to 40 points", color = White, fontSize = 11.sp); Text("Velocity · up to 25 · total views · up to 20 · freshness · up to 15", color = Muted, fontSize = 11.sp); Text("0–29 low · 30–49 monitor · 50–69 promising · 70–84 high · 85–100 exceptional. It is a prioritization score, not a probability.", color = Gold, fontSize = 10.sp) }
        SectionTitle("Top discoveries", "Ranked by transparent discovery score")
        if (videos.isEmpty()) EmptyState("No real discoveries yet", "Connect the Worker and run a scan. Demo data is intentionally not shown.")
        videos.sortedByDescending { it.score?.score ?: 0 }.take(5).forEach { VideoRow(it, { open(it) }, null) }
        SectionTitle("Fastest measured growth", "Only videos with repeated local observations")
        val growthIds = measuredGrowth.filterValues { it != Long.MIN_VALUE }.toList().sortedByDescending { it.second }.take(3)
        if (growthIds.isEmpty()) Text("No measured growth yet. Save a video and refresh its stats over time.", color = Muted, fontSize = 11.sp)
        growthIds.forEach { pair -> videos.firstOrNull { it.videoId == pair.first }?.let { v -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(v.title, Modifier.weight(1f), color = White, fontSize = 11.sp, maxLines = 2); Text("+${n(pair.second)} views", color = Mint, fontSize = 10.sp) } } }
        SectionTitle("Recently discovered")
        discoveries.take(3).forEach { record -> Text("${videos.firstOrNull { it.videoId == record.videoId }?.title ?: record.videoId} · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(record.firstSeenAt))}", color = Muted, fontSize = 10.sp) }
        SectionTitle("Recommended investigations")
        Text("Prioritize high-score videos with small subscriber counts, then monitor repeated snapshots to confirm whether momentum is accelerating.", color = Muted, fontSize = 11.sp)
    }
}

@Composable private fun DiscoverScreen(scanning: Boolean, maxResults: Int, setMax: (Int) -> Unit, nextPageToken: String?, scan: (String,String,String,String,String,String,String?) -> Unit, cancel: () -> Unit, videos: List<VideoDto>, dao: RadarDao, open: (VideoDto) -> Unit, save: (VideoDto) -> Unit, scanMessage: String, errorMessage: String?, randomSelection: String, rapidGrowth: String, minimumViewsSetting: String, subscriberCeilingSetting: String, videoLengthSetting: String, ageFilterEnabled: String, videoAgeSetting: String) {
    var query by remember { mutableStateOf("") }; var niche by remember { mutableStateOf("All niches") }; var age by remember(ageFilterEnabled, videoAgeSetting) { mutableStateOf(if (ageFilterEnabled == "true") videoAgeSetting else "Any time") }; var subs by remember(subscriberCeilingSetting) { mutableStateOf("Custom") }; var views by remember(minimumViewsSetting) { mutableStateOf("Custom") }; var format by remember { mutableStateOf("All formats") }; var videoLength by remember(videoLengthSetting) { mutableStateOf(videoLengthSetting) }; var customSubs by remember(subscriberCeilingSetting) { mutableStateOf(subscriberCeilingSetting) }; var customViews by remember(minimumViewsSetting) { mutableStateOf(minimumViewsSetting) }; var customAge by remember { mutableStateOf("") }; var sort by remember { mutableStateOf("Viral score") }
    var growthById by remember { mutableStateOf<Map<String,Long>>(emptyMap()) }
    LaunchedEffect(videos) { growthById = withContext(Dispatchers.IO) { videos.associate { v -> val obs=dao.observations(v.videoId); v.videoId to if (obs.size >= 2) obs.last().views - obs.first().views else Long.MIN_VALUE } } }
    ScreenColumn {
        Block {
            SectionTitle("Discovery controls", "Combine filters to surface small-channel breakouts")
            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Topic or keyword") }, placeholder = { Text("e.g. faceless history documentary") }, singleLine = true, shape = RoundedCornerShape(12.dp))
            FilterChoice("Niche", niche, niches) { niche = it }
            FilterChoice("Video age", age, listOf("Any time", "1 day", "3 days", "7 days", "14 days", "30 days", "90 days", "180 days", "365 days", "Custom")) { age = it }
            FilterChoice("Subscriber ceiling", subs, listOf("Under 1k", "Under 5k", "Under 10k", "Under 25k", "Under 50k", "Custom")) { subs = it }
            FilterChoice("Minimum views", views, listOf("100,000+", "250,000+", "500,000+", "1,000,000+", "Custom")) { views = it }
            if (subs == "Custom") OutlinedTextField(customSubs,{customSubs=it},label={Text("Custom subscriber ceiling")},modifier=Modifier.fillMaxWidth())
            if (views == "Custom") OutlinedTextField(customViews,{customViews=it},label={Text("Custom minimum views")},modifier=Modifier.fillMaxWidth())
            if (age == "Custom") OutlinedTextField(customAge,{customAge=it},label={Text("Age in days")},modifier=Modifier.fillMaxWidth())
            FilterChoice("Channel format", format, listOf("All formats", "Likely faceless", "Possibly faceless", "Personality-led", "Unknown")) { format = it }
            FilterChoice("Video type", videoLength, listOf("All video lengths", "Shorts (up to 3 minutes)", "Long-form (over 5 minutes)")) { videoLength = it }
            FilterChoice("Sort by", sort, listOf("Viral score", "Views", "Views per day", "Measured growth", "Newest", "Smallest subscriber count", "Views/subscriber ratio")) { sort = it }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Result limit", color = Muted, modifier = Modifier.weight(1f), fontSize = 12.sp); listOf(10,25).forEach { FilterChip(selected = maxResults == it, onClick = { setMax(it) }, label = { Text("$it") }) } }
            Button(onClick = { scan(query,niche,if (age == "Custom") "${customAge} days" else if (age == "Any time") "" else age,if (subs == "Custom") customSubs else subs,if (views == "Custom") customViews else views,format,null) }, enabled = !scanning, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) { if (scanning) CircularProgressIndicator(Modifier.size(17.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text(if (scanning) "Scanning…" else "Run discovery scan") }
            if (scanning) TextButton(onClick = cancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel scan", color = Red) }
            Text(scanMessage, color = if (scanMessage.startsWith("Scan complete")) Mint else Muted, fontSize = 11.sp)
            if (!errorMessage.isNullOrBlank()) Text(errorMessage, color = Red, fontSize = 11.sp)
            if (!scanning && nextPageToken != null) OutlinedButton(onClick = { scan(query,niche,if (age == "Custom") "${customAge} days" else if (age == "Any time") "" else age,if (subs == "Custom") customSubs else subs,if (views == "Custom") customViews else views,format,nextPageToken) }, modifier = Modifier.fillMaxWidth()) { Text("Load next page") }
            Text("Search results are sampled by YouTube's API, not exhaustive. Subscriber and engagement counts may be hidden or unavailable.", color = Muted, fontSize = 10.sp)
        }
        val minViewsThreshold = parseMetric(if (views == "Custom") customViews else views) ?: 100000L
        val subscriberThreshold = parseMetric(if (subs == "Custom") customSubs else subs) ?: 10000L
        val maxAgeHours = if (age == "Any time") null else parseAgeHours(if (age == "Custom") "${customAge} days" else age)
        val ageCutoff = maxAgeHours?.let { System.currentTimeMillis() - it * 3_600_000L }
        val lengthFiltered = videos.filter { video ->
            val seconds = durationSeconds(video.duration)
            val lengthOk = when (videoLength) {
                "Shorts (up to 3 minutes)" -> seconds != null && seconds <= 180L
                "Long-form (over 5 minutes)" -> seconds != null && seconds > 300L
                else -> true
            }
            val viewsOk = (video.viewCount ?: 0L) >= minViewsThreshold
            val subscribersOk = video.subscriberCount == null || video.subscriberCount <= subscriberThreshold
            val publishedAt = runCatching { java.time.Instant.parse(video.publishedAt ?: "").toEpochMilli() }.getOrNull()
            val ageOk = ageCutoff == null || publishedAt == null || publishedAt >= ageCutoff
            lengthOk && viewsOk && subscribersOk && ageOk
        }
        SectionTitle("Results", "${lengthFiltered.size} matching videos · ${videos.size} cached in total")
        val ordered = when (if (rapidGrowth == "true" && sort == "Viral score") "Measured growth" else sort) { "Views" -> lengthFiltered.sortedByDescending { it.viewCount ?: 0 }; "Views per day" -> lengthFiltered.sortedByDescending { viewsPerDay(it) }; "Measured growth" -> lengthFiltered.sortedByDescending { growthById[it.videoId] ?: Long.MIN_VALUE }; "Newest" -> lengthFiltered.sortedByDescending { it.publishedAt ?: "" }; "Smallest subscriber count" -> lengthFiltered.sortedBy { it.subscriberCount ?: Long.MAX_VALUE }; "Views/subscriber ratio" -> lengthFiltered.sortedByDescending { (it.viewCount ?: 0).toDouble() / maxOf(1L,it.subscriberCount ?: 1L) }; else -> lengthFiltered.sortedByDescending { it.score?.score ?: 0 } }
        val presentationOrder = remember(ordered, randomSelection) { if (randomSelection == "true") ordered.shuffled() else ordered }
        if (presentationOrder.isEmpty()) EmptyState("Waiting for your first scan", "Your discovery list will fill with real API results once the backend is connected.")
        presentationOrder.forEach { VideoRow(it, { open(it) }, { save(it) }) }
    }
}

@Composable private fun FilterChoice(label: String, value: String, options: List<String>, onPick: (String) -> Unit) { var expanded by remember { mutableStateOf(false) }; Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) { Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f)); Box { TextButton(onClick = { expanded = true }) { Text(value, color = Gold, fontSize = 12.sp); Icon(Icons.Default.ExpandMore, null, tint = Gold) }; DropdownMenu(expanded, { expanded = false }) { options.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onPick(it); expanded = false }) } } } } }

@Composable private fun VideoRow(v: VideoDto, open: () -> Unit, save: (() -> Unit)?) {
    Card(onClick = open, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!v.thumbnailUrl.isNullOrBlank()) AsyncImage(model = v.thumbnailUrl, contentDescription = "Video thumbnail", modifier = Modifier.size(88.dp, 54.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text(v.title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis); Text(v.channelTitle ?: "Unknown channel", color = Muted, fontSize = 10.sp) }
                Surface(color = scoreColor(v.score?.score ?: 0).copy(alpha = .16f), shape = RoundedCornerShape(10.dp)) { Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("${v.score?.score ?: "—"}", color = scoreColor(v.score?.score ?: 0), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp); Text("SCORE", color = Muted, fontSize = 8.sp) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { SmallStat("Views", n(v.viewCount)); SmallStat("Subs", n(v.subscriberCount)); SmallStat("Views/sub", ratio(v.viewCount,v.subscriberCount)) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(v.faceless?.label ?: "Format unknown", color = Mint, fontSize = 10.sp, modifier = Modifier.weight(1f))
                if (save != null) TextButton(onClick = save, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Icon(Icons.Default.BookmarkAdd, null, Modifier.size(16.dp)); Text("Save", fontSize = 10.sp) }
                Text("Details  ›", color = Gold, fontSize = 10.sp)
            }
        }
    }
}
@Composable private fun SmallStat(label: String, value: String) { Row(verticalAlignment = Alignment.CenterVertically) { Text("$label ", color = Muted, fontSize = 9.sp); Text(value, color = White, fontSize = 10.sp, fontWeight = FontWeight.Bold) } }
// YouTube API duration is ISO-8601 (for example PT45S, PT2M10S, PT1H5M).
// The API does not provide Shorts classification/aspect ratio, so this is a duration-based estimate.
private fun durationSeconds(value: String?): Long? {
    if (value.isNullOrBlank() || !value.startsWith("PT")) return null
    val match = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?").matchEntire(value) ?: return null
    val hours = match.groupValues[1].toLongOrNull() ?: 0L
    val minutes = match.groupValues[2].toLongOrNull() ?: 0L
    val seconds = match.groupValues[3].toLongOrNull() ?: 0L
    return hours * 3600L + minutes * 60L + seconds
}

private fun parseMetric(value: String): Long? {
    val raw = value.lowercase().replace(",", "").replace("under", "").replace("+", "").trim()
    val number = Regex("[0-9]+(?:\\.[0-9]+)?").find(raw)?.value?.toDoubleOrNull() ?: return null
    val multiplier = when { raw.contains("k") -> 1_000.0; raw.contains("m") -> 1_000_000.0; else -> 1.0 }
    return (number * multiplier).toLong()
}
private fun parseAgeHours(value: String): Long? {
    val raw = value.lowercase().trim()
    val number = Regex("[0-9]+(?:\\.[0-9]+)?").find(raw)?.value?.toDoubleOrNull() ?: return null
    return (number * if (raw.contains("hour")) 1.0 else 24.0).toLong()
}
private fun applyClientFilters(items: List<VideoDto>, age: String, ceiling: String, minimum: String, format: String): List<VideoDto> {
    val maxSubs = parseMetric(ceiling)
    val minViews = parseMetric(minimum)
    val maxAgeHours = parseAgeHours(age)
    val cutoff = maxAgeHours?.let { System.currentTimeMillis() - it * 3_600_000L }
    return items.filter { v ->
        val subscriberOk = maxSubs == null || v.subscriberCount == null || v.subscriberCount < maxSubs
        val viewsOk = minViews == null || v.viewCount == null || v.viewCount >= minViews
        val published = runCatching { java.time.Instant.parse(v.publishedAt ?: "").toEpochMilli() }.getOrNull()
        val ageOk = cutoff == null || published == null || published >= cutoff
        val label = v.faceless?.label?.lowercase() ?: "unknown"
        val formatOk = when (format) { "Likely faceless" -> label.contains("likely_faceless"); "Possibly faceless" -> label.contains("possibly_faceless"); "Personality-led" -> label.contains("personality"); "Unknown" -> label == "unknown"; else -> true }
        subscriberOk && viewsOk && ageOk && formatOk
    }
}

private fun viewsPerDay(v: VideoDto): Double { val published = runCatching { java.time.Instant.parse(v.publishedAt ?: return 0.0).toEpochMilli() }.getOrNull() ?: return 0.0; val days = ((System.currentTimeMillis()-published).coerceAtLeast(1L))/86400000.0; return (v.viewCount ?: 0L)/days }
private fun ratio(views: Long?, subs: Long?): String = if (views == null || subs == null || subs == 0L) "—" else String.format(Locale.US,"%.1fx",views.toDouble()/subs)
private fun scoreColor(s: Int) = when { s >= 85 -> Gold; s >= 70 -> Mint; s >= 50 -> Color(0xFF78B8FF); else -> Muted }

@Composable private fun TrendGraph(values: List<Long>) {
    Canvas(Modifier.fillMaxWidth().height(76.dp).background(Panel2, RoundedCornerShape(10.dp)).padding(8.dp)) {
        if (values.size < 2) return@Canvas
        val minV = values.minOrNull()?.toFloat() ?: 0f
        val range = ((values.maxOrNull()?.toFloat() ?: 1f) - minV).coerceAtLeast(1f)
        val pts = values.mapIndexed { i, v -> Offset(x = size.width * i / (values.size - 1), y = size.height - ((v.toFloat() - minV) / range * size.height)) }
        pts.zipWithNext().forEach { (a,b) -> drawLine(Mint, a, b, strokeWidth = 4f) }
    }
}

@Composable private fun GrowthScreen(saved: List<SavedItem>, dao: RadarDao, api: RadarApi?, showError: (String) -> Unit) {
    var observations by remember { mutableStateOf<Map<String,List<Observation>>>(emptyMap()) }
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val trackedVideos = saved.filter { it.kind == "video" }
    LaunchedEffect(trackedVideos) { observations = withContext(Dispatchers.IO) { trackedVideos.associate { it.id to dao.observations(it.id) } } }
    ScreenColumn {
        Block { SectionTitle("Growth intelligence", "Your own observations, not invented historical data"); Text("YouTube does not expose a complete historical timeline for arbitrary videos. Growth begins when Radar records the first snapshot. Refresh again later to calculate actual change.", color = Muted, fontSize = 12.sp); Text("Hourly and daily rates require at least two time-separated observations. Acceleration requires three or more.", color = Gold, fontSize = 11.sp) }
        if (trackedVideos.isEmpty()) EmptyState("Nothing being tracked", "Save a video discovery to start collecting snapshots.")
        trackedVideos.forEach { item ->
            val obs = observations[item.id].orEmpty()
            Block {
                Text(item.title, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 2)
                Text("${obs.size} observations", color = Muted, fontSize = 10.sp)
                if (obs.size >= 2) {
                    TrendGraph(obs.map { it.views })
                    val first = obs.first(); val last = obs.last(); val delta = last.views - first.views
                    Text("${if (delta >= 0) "+" else ""}${n(delta)} views since tracking began", color = if (delta >= 0) Mint else Red, fontWeight = FontWeight.Bold)
                    val hours = ((last.observedAt-first.observedAt).coerceAtLeast(1L))/3600000.0
                    Text("${String.format(Locale.US,"%.1f",delta/hours)} views/hour · ${String.format(Locale.US,"%.1f",delta/(hours/24.0))} views/day", color = Muted, fontSize = 11.sp)
                    val trend = if (obs.size >= 3) { val r1=(obs[1].views-obs[0].views).toDouble()/(obs[1].observedAt-obs[0].observedAt).coerceAtLeast(1L); val r2=(obs.last().views-obs[obs.size-2].views).toDouble()/(obs.last().observedAt-obs[obs.size-2].observedAt).coerceAtLeast(1L); when { delta < 0 -> "declining"; r2 > r1 -> "accelerating"; r2 < r1 -> "slowing"; else -> "steady" } } else "insufficient observations"
                    Text("Trend: $trend", color = Gold, fontSize = 10.sp)
                } else Text("Insufficient observations · record another snapshot later", color = Muted, fontSize = 11.sp)
                Button(onClick = {
                    scope.launch {
                        refreshing = true
                        try {
                            if (api == null) throw IllegalStateException("Configure the Worker URL in Settings to refresh live stats.")
                            val result = withContext(Dispatchers.IO) { api.refresh(item.id) }
                            val views = (result["viewCount"] as? Number)?.toLong() ?: 0L
                            withContext(Dispatchers.IO) { dao.observe(Observation(videoId=item.id,views=views)) }
                            observations = withContext(Dispatchers.IO) { saved.associate { it.id to dao.observations(it.id) } }
                        } catch (e: Exception) { showError(e.message ?: "Refresh failed") }
                        refreshing = false
                    }
                }, enabled = !refreshing, colors = ButtonDefaults.buttonColors(containerColor = Panel2)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(5.dp)); Text("Refresh snapshot") }
            }
        }
    }
}

@Composable private fun WatchlistScreen(saved: List<SavedItem>, videos: List<VideoDto>, remove: (String) -> Unit, open: (VideoDto) -> Unit, openChannel: (String) -> Unit, snapshot: (String) -> Unit) {
    var kind by remember { mutableStateOf("All") }; var sort by remember { mutableStateOf("Newest saved") }
    ScreenColumn {
        Row(verticalAlignment = Alignment.CenterVertically) { SectionTitle("Your watchlist", "${saved.size} saved items"); Spacer(Modifier.weight(1f)); FilterChoice("Type", kind, listOf("All","Videos","Channels")) { kind=it } }
        FilterChoice("Sort", sort, listOf("Newest saved","Title")) { sort=it }
        val filtered = saved.filter { kind == "All" || (kind == "Videos" && it.kind == "video") || (kind == "Channels" && it.kind == "channel") }.let { if (sort == "Title") it.sortedBy { x -> x.title.lowercase() } else it }
        if (filtered.isEmpty()) EmptyState("Your watchlist is empty", "Save videos from Discover to keep them here across app restarts.")
        filtered.forEach { item ->
            Block {
                Text(item.title, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("${item.kind.uppercase()} · saved ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(item.savedAt))}", color = Muted, fontSize = 10.sp)
                val v = videos.firstOrNull { it.videoId == item.id }
                if (v != null) Text("Views: ${n(v.viewCount)} · subscribers: ${n(v.subscriberCount)} · score: ${v.score?.score ?: "—"}", color = Gold, fontSize = 10.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (v != null) OutlinedButton(onClick = { open(v) }) { Text("Open profile") }
                    if (item.kind == "channel") OutlinedButton(onClick = { openChannel(item.id) }) { Text("Channel profile") }
                    if (v != null) OutlinedButton(onClick = { snapshot(item.id) }) { Text("Record cached snapshot") }
                    TextButton(onClick = { remove(item.id) }) { Text("Remove", color = Red) }
                }
            }
        }
    }
}

@Composable private fun HistoryScreen(cache: List<CachedVideo>, videos: List<VideoDto>, scanHistory: List<ScanRecord>, discoveries: List<DiscoveryRecord>, open: (VideoDto) -> Unit, reload: () -> Unit) {
    ScreenColumn {
        Block { SectionTitle("Discovery history", "Persisted locally on this device"); Text("Cached videos: ${cache.size} · scan sessions: ${scanHistory.size}", color = Muted, fontSize = 12.sp); OutlinedButton(onClick = reload) { Icon(Icons.Default.Refresh, null); Text("Reload local history") } }
        SectionTitle("Scan sessions")
        if (scanHistory.isEmpty()) EmptyState("No scan sessions yet", "Successful and failed scan attempts are stored here.")
        scanHistory.forEach { record -> Block { Text("${record.query} · ${record.status.uppercase()}", color = White, fontWeight = FontWeight.Bold); Text("${record.resultCount} results · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(record.startedAt))}", color = Muted, fontSize = 10.sp); Text(record.message, color = Muted, fontSize = 11.sp); record.estimatedUnits?.let { Text("Estimated search units: $it", color = Gold, fontSize = 10.sp) } } }
        SectionTitle("First-seen performance records")
        discoveries.forEach { record -> Block { Text(videos.firstOrNull { it.videoId == record.videoId }?.title ?: record.videoId, color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text("First discovered: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(record.firstSeenAt))}", color = Muted, fontSize = 10.sp); Text("Original views: ${n(record.originalViews)} · original subscribers: ${n(record.originalSubscribers)} · original score: ${record.originalScore ?: "—"}", color = Gold, fontSize = 10.sp); val latest=videos.firstOrNull { it.videoId == record.videoId }; if(latest != null) Text("Latest views: ${n(latest.viewCount)} · change: ${if(latest.viewCount != null && record.originalViews != null) n(latest.viewCount-record.originalViews) else "—"}", color = Mint, fontSize = 10.sp) } }
        SectionTitle("Discovered videos")
        if (videos.isEmpty()) EmptyState("No discoveries in history", "Videos returned by successful scans are stored locally for later review.")
        videos.forEach { VideoRow(it, { open(it) }, null) }
    }
}

private fun scheduleRadarScan(choice: String, endpoint: String) {
    val context = appContext ?: return
    val manager = WorkManager.getInstance(context)
    if (choice == "Off") { manager.cancelUniqueWork("viral-radar-periodic-scan"); return }
    if (!endpoint.startsWith("https://")) return
    val hours = when (choice) { "Every 6 hours" -> 6L; "Every 12 hours" -> 12L; "Daily" -> 24L; else -> return }
    val data = androidx.work.Data.Builder().putString("endpoint", endpoint).putString("query", "trending topics").build()
    val request = PeriodicWorkRequestBuilder<ScanWorker>(hours, TimeUnit.HOURS).setInputData(data).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
    manager.enqueueUniquePeriodicWork("viral-radar-periodic-scan", ExistingPeriodicWorkPolicy.UPDATE, request)
}

private var appContext: android.content.Context? = null

@Composable private fun SettingsScreen(
    endpoint: String, onEndpoint: (String) -> Unit, save: (String) -> Unit,
    auto: String, onAuto: (String) -> Unit, quota: String, api: RadarApi?, setQuota: (String) -> Unit,
    launchDiscovery: Boolean, setLaunchDiscovery: (Boolean) -> Unit,
    randomSelection: Boolean, setRandomSelection: (Boolean) -> Unit,
    rapidGrowth: Boolean, setRapidGrowth: (Boolean) -> Unit,
    minimumViews: String, setMinimumViews: (String) -> Unit,
    subscriberCeiling: String, setSubscriberCeiling: (String) -> Unit,
    ageFilterEnabled: Boolean, setAgeFilterEnabled: (Boolean) -> Unit,
    videoAge: String, setVideoAge: (String) -> Unit,
    videoLength: String, setVideoLength: (String) -> Unit
) {
    appContext = LocalContext.current.applicationContext
    var checking by remember { mutableStateOf(false) }; var health by remember { mutableStateOf("Not checked") }; val scope = rememberCoroutineScope()
    var minViewsDraft by remember(minimumViews) { mutableStateOf(minimumViews) }
    var subsDraft by remember(subscriberCeiling) { mutableStateOf(subscriberCeiling) }
    ScreenColumn {
        Block {
            SectionTitle("Discovery preferences", "These settings are saved on this phone and can be changed anytime")
            SettingSwitch("Discover automatically on app launch", launchDiscovery, setLaunchDiscovery)
            SettingSwitch("Randomise the discovery list", randomSelection, setRandomSelection)
            SettingSwitch("Prioritise rapid view growth", rapidGrowth, setRapidGrowth)
            OutlinedTextField(minViewsDraft, { minViewsDraft = it.filter { it.isDigit() } }, modifier = Modifier.fillMaxWidth(), label = { Text("Minimum views (no maximum)") }, singleLine = true)
            OutlinedButton(onClick = { setMinimumViews(minViewsDraft) }, modifier = Modifier.fillMaxWidth()) { Text("Save minimum views") }
            OutlinedTextField(subsDraft, { subsDraft = it.filter { it.isDigit() } }, modifier = Modifier.fillMaxWidth(), label = { Text("Small-channel subscriber ceiling") }, singleLine = true)
            OutlinedButton(onClick = { setSubscriberCeiling(subsDraft) }, modifier = Modifier.fillMaxWidth()) { Text("Save subscriber limit") }
            SettingSwitch("Apply publishing-age filter", ageFilterEnabled, setAgeFilterEnabled)
            FilterChoice("Video age", videoAge, listOf("1 day", "3 days", "7 days", "14 days", "30 days", "90 days", "180 days", "365 days")) { setVideoAge(it) }
            FilterChoice("Video length", videoLength, listOf("All video lengths", "Shorts (up to 3 minutes)", "Long-form (over 5 minutes)")) { setVideoLength(it) }
            Text("The default is 100,000 minimum views, no upper limit, a 10,000-subscriber ceiling, and long-form videos over 5 minutes. Shorts are duration-based estimates because YouTube's API does not label every Short directly.", color = Muted, fontSize = 10.sp)
        }
        Block {
            SectionTitle("Backend connection", "Only the Worker URL belongs in the Android app")
            OutlinedTextField(endpoint, onEndpoint, modifier = Modifier.fillMaxWidth(), label = { Text("Cloudflare Worker HTTPS URL") }, placeholder = { Text("https://your-worker.workers.dev") }, singleLine = true)
            Button(onClick = { save(endpoint) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Save connection") }
            OutlinedButton(onClick = {
                scope.launch { checking = true; health = try { val a = api ?: RadarApi.create(endpoint); val h = withContext(Dispatchers.IO) { a.health() }; if (h["ok"] == true) "Connected · YouTube key configured: ${h["youtubeConfigured"]}" else "Worker responded, check configuration" } catch(e: Exception) { "Connection failed: ${e.message}" }; checking = false }
            }, enabled = !checking && endpoint.isNotBlank(), modifier = Modifier.fillMaxWidth()) { if (checking) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Default.CloudDone, null); Spacer(Modifier.width(8.dp)); Text("Test backend connection") }
            Text(health, color = if (health.startsWith("Connected")) Mint else Muted, fontSize = 11.sp)
            Text("Security: YouTube API key must remain a Cloudflare Worker secret. It is never entered or stored in this app.", color = Gold, fontSize = 11.sp)
        }
        Block {
            SectionTitle("Background scan schedule", "Separate from scanning when the app opens")
            FilterChoice("Automatic scans", auto, listOf("Off", "Every 6 hours", "Every 12 hours", "Daily"), onAuto)
            Text("Android may delay background scans due to battery optimisation, connectivity and system scheduling.", color = Muted, fontSize = 11.sp)
        }
        Block {
            SectionTitle("Quota & usage")
            Text(quota, color = Muted, fontSize = 11.sp)
            Button(onClick = { scope.launch { try { val a = api ?: RadarApi.create(endpoint); val q = withContext(Dispatchers.IO) { a.quota() }; setQuota(q["note"]?.toString() ?: "Quota estimate retrieved; verify actual usage in Google Cloud Console.") } catch (e: Exception) { setQuota("Quota endpoint unavailable: ${e.message}") } } }) { Text("Refresh quota estimate") }
            Text("YouTube API search.list is typically the expensive discovery call. Estimates are not authoritative; confirm quota and actual usage in Google Cloud Console.", color = Muted, fontSize = 11.sp)
        }
        Block {
            SectionTitle("About Viral Radar")
            Text("Build 1.2 · Android 8.0+ · Owner: Kingdaddy606", color = Muted, fontSize = 11.sp)
            Text("Viral score is an internal prioritization score, not a probability of virality. Rapid growth is measured only after repeated snapshots.", color = Muted, fontSize = 11.sp)
            Text("Data is sourced from the official YouTube Data API through your backend. Search results are samples, not exhaustive platform coverage.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable private fun SettingSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = White, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable private fun VideoDetailDialog(v: VideoDto, isSaved: Boolean, save: () -> Unit, saveChannel: () -> Unit, openChannel: (String) -> Unit, close: () -> Unit) {
    AlertDialog(onDismissRequest = close, containerColor = Panel, title = { Text(v.title, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(v.channelTitle ?: "Unknown channel", color = Gold, fontWeight = FontWeight.SemiBold)
            v.channelId?.let { TextButton(onClick = { openChannel(it) }) { Text("Open channel intelligence profile") } }
            Text("Views: ${n(v.viewCount)} · Subscribers: ${n(v.subscriberCount)}", color = White, fontSize = 12.sp)
            v.description?.takeIf { it.isNotBlank() }?.let { Text(it, color = Muted, fontSize = 11.sp, maxLines = 5, overflow = TextOverflow.Ellipsis) }
            Text("Likes: ${n(v.likeCount)} · Comments: ${n(v.commentCount)}", color = Muted, fontSize = 11.sp)
            Text("Viral score: ${v.score?.score ?: "Unavailable"} / 100 · ${v.score?.category ?: "Not scored"}", color = scoreColor(v.score?.score ?: 0), fontWeight = FontWeight.Bold)
            Text(v.score?.note ?: "Score explanation unavailable.", color = Muted, fontSize = 11.sp)
            Divider(color = Panel2)
            Text("Channel format: ${v.faceless?.label ?: "Unknown"} · confidence ${v.faceless?.confidence ?: "—"}", color = Mint, fontSize = 11.sp)
            Text(v.faceless?.reason ?: "No metadata classification reason available.", color = Muted, fontSize = 11.sp)
            Text("This is metadata analysis, not visual verification of whether a person appears.", color = Gold, fontSize = 10.sp)
            Text("Published: ${v.publishedAt ?: "Unknown"} · Duration: ${v.duration ?: "Unknown"}", color = Muted, fontSize = 10.sp)
            v.youtubeUrl?.let { url -> val context = androidx.compose.ui.platform.LocalContext.current; TextButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }) { Text("Open on YouTube") } }
        }
    }, confirmButton = { Row { TextButton(onClick = save, enabled = !isSaved) { Text(if (isSaved) "Saved" else "Save video") }; TextButton(onClick = saveChannel) { Text("Save channel") }; TextButton(onClick = close) { Text("Close") } } })
}

@Composable private fun EmptyState(title: String, body: String) { Block { Icon(Icons.Default.Explore, null, tint = Red, modifier = Modifier.size(26.dp)); Text(title, color = White, fontWeight = FontWeight.Bold); Text(body, color = Muted, fontSize = 12.sp) } }


@Composable private fun ChannelDetailDialog(data: Map<String,Any?>, close: () -> Unit) {
    val title = data["title"]?.toString() ?: data["channel_title"]?.toString() ?: "Channel profile"
    AlertDialog(onDismissRequest = close, containerColor = Panel, title = { Text(title, color = White, fontWeight = FontWeight.Bold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Subscribers: ${data["subscriber_count"] ?: "Unavailable"}", color = Gold)
            Text("Total views: ${data["view_count"] ?: "Unavailable"}", color = White)
            Text("Videos: ${data["video_count"] ?: "Unavailable"}", color = White)
            Text("Channel ID: ${data["channel_id"] ?: "Unavailable"}", color = Muted, fontSize = 10.sp)
            Text("Metrics are supplied by the official YouTube Data API. Hidden subscriber counts remain unavailable.", color = Muted, fontSize = 11.sp)
        }
    }, confirmButton = { TextButton(onClick = close) { Text("Close") } })
}
