# YouTube Viral Radar — Android client + Cloudflare backend

**Owner/project label:** Kingdaddy606  
**Platform:** Native Android (Kotlin + Jetpack Compose), Android 8.0 / API 26+  
**Backend:** Cloudflare Workers + D1  
**Data provider:** Official YouTube Data API v3 only

This repository is the implementation workspace for the supplied 29-page master specification. The Android client is designed to be usable once the Worker endpoints are deployed. No YouTube API key is placed in the APK.

## Android client implemented

- Six native sections: Dashboard, Discover, Growth Tracker, Watchlist, History, Settings.
- Premium dark UI, adaptive launcher icon, branded app label and Android 8+ manifest.
- Worker HTTPS endpoint setting stored with DataStore; connection health check.
- Discovery query, niche, age, subscriber ceiling, minimum views, channel-format, custom thresholds, result count and sorting controls.
- Client-side result filtering for returned API samples, with score, views, subscriber count, ratio, thumbnails and faceless metadata.
- Video intelligence dialog with score explanation, metadata classification limitations, channel profile action and Open on YouTube.
- Channel profile view and local video/channel watchlist.
- Room persistence for saved items, cached videos, observation snapshots, scan sessions and first-seen discovery records.
- Growth charts and measured rates based only on snapshots recorded after tracking begins.
- Manual scan cancellation, success/failure history, offline cache retention and clear connection/quota messaging.
- Optional 6-hour, 12-hour or daily WorkManager scans (Android may delay execution).
- No demo discoveries or fabricated statistics are displayed.

## Android build

The repository is configured for Android Gradle Plugin 8.7.3, Gradle 8.9 and Java 17.

```bash
gradle --no-daemon :app:assembleDebug
gradle --no-daemon :app:testDebugUnitTest
```

The GitHub Actions workflow is intentionally supplied as a **separate file**, not inside this source ZIP. After uploading the source files to your GitHub repository, create the workflow file in GitHub at this exact path:

`.github/workflows/build-android.yml`

Paste the contents of the separate `build-android.yml` file into it, then commit the new file. GitHub Actions will then provision Gradle and build/upload the debug APK on pushes, pull requests, or manual runs. This execution environment did not include Android SDK or Gradle, so a local APK build has **not** been claimed.

## Backend deployment (next integration stage)

1. Create a Cloudflare Worker and D1 database.
2. Update `backend/wrangler.toml` with the D1 database ID.
3. From `backend/`, install dependencies and apply the migration:

   ```bash
   npm install
   npx wrangler d1 migrations apply viral-radar --remote
   ```

4. Set the YouTube key as a Worker secret (never as an Android build variable):

   ```bash
   npx wrangler secret put YOUTUBE_API_KEY
   ```

5. Deploy with `npm run deploy` and configure the resulting HTTPS Worker URL in Android Settings.

## API contract expected by the Android app

- `GET /api/health`
- `POST /api/scan`
- `GET /api/discoveries?limit=...`
- `GET /api/videos/{videoId}`
- `GET /api/channels/{channelId}`
- `GET /api/videos/{videoId}/history`
- `POST /api/videos/{videoId}/refresh`
- `GET /api/quota`
- `GET /api/history`

The Android client sends query, result limit, niche, age, subscriber ceiling, minimum views and channel-format filters to `/api/scan`. The backend stage must implement and validate those filters, paging, term rotation, quota-aware batching/caching, D1 history persistence, rate limiting, and consistent response shapes. Local filtering is also applied to returned scan samples.

## Scoring and classification

The discovery score is a transparent heuristic: views/subscriber ratio (up to 40), velocity (up to 25), total views (up to 20), freshness (up to 15). It is not a probability or guarantee. Hidden subscriber counts remain unavailable and do not create a fabricated ratio.

Faceless classification is based on title/description metadata only. It is not visual verification and can return unknown or low confidence.

## Validation performed in this workspace

- Backend scoring/classifier unit tests: **4 passed** (`npm test`).
- Android source, manifest, resources and Gradle configuration have been assembled into the project bundle.
- Android compile/instrumentation tests: **not run** because Android SDK and Gradle are unavailable in this environment.

## Important integration work still required

The Android-side screens and persistence are implemented, but the backend is not yet production-complete. Before treating the app as fully operational, finish the Worker/D1 endpoint behavior described above, connect the Android client to that deployment, and run the GitHub Actions APK build plus device/emulator tests. The YouTube API key must remain a Cloudflare secret.
