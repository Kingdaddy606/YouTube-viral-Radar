package com.kingdaddy606.viralradar.data

import retrofit2.http.*
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.squareup.moshi.Moshi
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.JsonReader
import com.squareup.moshi.JsonWriter
import com.squareup.moshi.Types
import java.lang.reflect.Type
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Accepts both the Android camelCase DTO format and raw Cloudflare D1 snake_case rows. */
private class DiscoveryResponseAdapterFactory : JsonAdapter.Factory {
    override fun create(type: Type, annotations: Set<Annotation>, moshi: Moshi): JsonAdapter<*>? {
        if (Types.getRawType(type) != DiscoveryResponse::class.java) return null
        val delegate = moshi.nextAdapter<DiscoveryResponse>(this, type, annotations)
        return object : JsonAdapter<DiscoveryResponse>() {
            override fun fromJson(reader: JsonReader): DiscoveryResponse? {
                return delegate.fromJsonValue(normalizeDiscoveryPayload(reader.readJsonValue()))
            }
            override fun toJson(writer: JsonWriter, value: DiscoveryResponse?) {
                delegate.toJson(writer, value)
            }
        }
    }
}

private fun normalizeDiscoveryPayload(value: Any?): Any? {
    val root = value as? Map<*, *> ?: return value
    val normalizedRoot = root.entries.associate { (k, v) ->
        (k?.toString() ?: "") to if (k?.toString() == "items" && v is List<*>) {
            v.map { normalizeVideoRow(it) }
        } else v
    }.toMutableMap()
    return normalizedRoot
}

private fun normalizeVideoRow(value: Any?): Any? {
    val row = value as? Map<*, *> ?: return value
    val result = row.entries.associate { (key, item) ->
        val rawKey = key?.toString() ?: ""
        val camelKey = when (rawKey) {
            "video_id" -> "videoId"
            "channel_id" -> "channelId"
            "thumbnail_url" -> "thumbnailUrl"
            "published_at" -> "publishedAt"
            "view_count" -> "viewCount"
            "like_count" -> "likeCount"
            "comment_count" -> "commentCount"
            "channel_title" -> "channelTitle"
            "subscriber_count" -> "subscriberCount"
            "youtube_url" -> "youtubeUrl"
            else -> rawKey
        }
        camelKey to item
    }.toMutableMap()

    val score = result["score"] as? Map<*, *>
    if (score == null && result.containsKey("viral_score")) {
        val number = (result["viral_score"] as? Number)?.toInt() ?: 0
        val category = when {
            number >= 85 -> "Exceptional"
            number >= 70 -> "High potential"
            number >= 50 -> "Promising"
            else -> "Monitor"
        }
        result["score"] = mapOf("score" to number, "category" to category, "note" to (result["score_reason"] ?: ""))
    }

    val faceless = result["faceless"] as? Map<*, *>
    if (faceless == null && (result.containsKey("faceless_label") || result.containsKey("faceless_reason"))) {
        result["faceless"] = mapOf(
            "label" to (result["faceless_label"] ?: "unknown"),
            "confidence" to "metadata-based",
            "reason" to (result["faceless_reason"] ?: "")
        )
    }

    if (result["youtubeUrl"] == null) {
        val id = result["videoId"]?.toString()
        if (!id.isNullOrBlank()) result["youtubeUrl"] = "https://www.youtube.com/watch?v=$id"
    }
    return result
}

interface RadarApi {
    @POST("api/scan") suspend fun scan(@Body request: ScanRequest): DiscoveryResponse
    @GET("api/discoveries") suspend fun discoveries(@Query("limit") limit: Int = 30): DiscoveryResponse
    @GET("api/videos/{id}") suspend fun video(@Path("id") id: String): Map<String, Any?>
    @GET("api/channels/{id}") suspend fun channel(@Path("id") id: String): Map<String, Any?>
    @GET("api/videos/{id}/history") suspend fun observations(@Path("id") id: String): Map<String, Any?>
    @POST("api/videos/{id}/refresh") suspend fun refresh(@Path("id") id: String): Map<String, Any?>
    @GET("api/quota") suspend fun quota(): Map<String, Any?>
    @GET("api/health") suspend fun health(): Map<String, Any?>
    companion object {
        fun create(baseUrl: String): RadarApi {
            require(baseUrl.startsWith("https://")) { "Use an HTTPS Worker URL." }
            val client=OkHttpClient.Builder().connectTimeout(15,TimeUnit.SECONDS).readTimeout(30,TimeUnit.SECONDS).build()
            return Retrofit.Builder().baseUrl(baseUrl.trimEnd('/')+"/").client(client).addConverterFactory(MoshiConverterFactory.create(Moshi.Builder().add(DiscoveryResponseAdapterFactory()).add(KotlinJsonAdapterFactory()).build())).build().create(RadarApi::class.java)
        }
    }
}
