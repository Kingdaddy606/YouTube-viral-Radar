package com.kingdaddy606.viralradar.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity(tableName="scan_sessions")
data class ScanRecord(@PrimaryKey(autoGenerate=true) val id: Long = 0, val startedAt: Long = System.currentTimeMillis(), val query: String, val resultCount: Int, val status: String, val message: String, val estimatedUnits: Int? = null)

@Entity(tableName="discovery_records")
data class DiscoveryRecord(@androidx.room.PrimaryKey val videoId: String, val firstSeenAt: Long, val originalViews: Long?, val originalSubscribers: Long?, val originalScore: Int?, val initialPayload: String, val latestPayload: String)

@Dao interface RadarDao {
    @Query("SELECT * FROM saved_items ORDER BY savedAt DESC") suspend fun saved(): List<SavedItem>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun save(item: SavedItem)
    @Query("DELETE FROM saved_items WHERE id=:id") suspend fun unsave(id: String)
    @Query("SELECT * FROM cached_videos ORDER BY cachedAt DESC") suspend fun cached(): List<CachedVideo>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun cache(video: CachedVideo)
    @Insert suspend fun observe(item: Observation)
    @Query("SELECT * FROM observations WHERE videoId=:id ORDER BY observedAt ASC") suspend fun observations(id: String): List<Observation>
    @Insert suspend fun addScan(record: ScanRecord)
    @Query("SELECT * FROM scan_sessions ORDER BY startedAt DESC LIMIT 100") suspend fun scanHistory(): List<ScanRecord>
    @Insert(onConflict=OnConflictStrategy.IGNORE) suspend fun addDiscovery(record: DiscoveryRecord)
    @Query("UPDATE discovery_records SET latestPayload=:payload WHERE videoId=:id") suspend fun updateDiscovery(id: String, payload: String)
    @Query("SELECT * FROM discovery_records ORDER BY firstSeenAt DESC") suspend fun discoveryRecords(): List<DiscoveryRecord>
}
@Database(entities=[SavedItem::class,CachedVideo::class,Observation::class,ScanRecord::class,DiscoveryRecord::class],version=3,exportSchema=true)
abstract class RadarDatabase: RoomDatabase() {
    abstract fun dao(): RadarDao
    companion object {
        private val MIGRATION_1_2 = object : Migration(1,2) { override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("CREATE TABLE IF NOT EXISTS scan_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, startedAt INTEGER NOT NULL, query TEXT NOT NULL, resultCount INTEGER NOT NULL, status TEXT NOT NULL, message TEXT NOT NULL, estimatedUnits INTEGER)") } }
        private val MIGRATION_2_3 = object : Migration(2,3) { override fun migrate(db: SupportSQLiteDatabase) { db.execSQL("CREATE TABLE IF NOT EXISTS discovery_records (videoId TEXT NOT NULL PRIMARY KEY, firstSeenAt INTEGER NOT NULL, originalViews INTEGER, originalSubscribers INTEGER, originalScore INTEGER, initialPayload TEXT NOT NULL, latestPayload TEXT NOT NULL)") } }
        @Volatile private var INSTANCE: RadarDatabase?=null
        fun get(context: Context): RadarDatabase = INSTANCE ?: synchronized(this) { INSTANCE ?: Room.databaseBuilder(context.applicationContext,RadarDatabase::class.java,"viral-radar.db").addMigrations(MIGRATION_1_2,MIGRATION_2_3).build().also { INSTANCE=it } }
    }
}
