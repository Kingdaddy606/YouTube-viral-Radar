package com.kingdaddy606.viralradar.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class ScanWorker(context: Context, params: WorkerParameters): CoroutineWorker(context,params) {
    override suspend fun doWork(): Result {
        val endpoint=inputData.getString("endpoint") ?: return Result.failure()
        val query=inputData.getString("query") ?: return Result.failure()
        return try {
            val response = RadarApi.create(endpoint).scan(ScanRequest(query,25))
            val dao = RadarDatabase.get(applicationContext).dao()
            val adapter = Moshi.Builder().add(KotlinJsonAdapterFactory()).build().adapter(VideoDto::class.java)
            response.items.forEach { video ->
                val payload=adapter.toJson(video)
                dao.addDiscovery(DiscoveryRecord(video.videoId,System.currentTimeMillis(),video.viewCount,video.subscriberCount,video.score?.score,payload,payload))
                dao.updateDiscovery(video.videoId,payload)
                dao.cache(CachedVideo(video.videoId,video.title,payload))
                dao.observe(Observation(videoId=video.videoId,views=video.viewCount ?: 0L))
            }
            dao.addScan(ScanRecord(query=query,resultCount=response.items.size,status="success",message="Background scan completed",estimatedUnits=response.quota?.searchUnitsEstimated))
            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else {
                runCatching { RadarDatabase.get(applicationContext).dao().addScan(ScanRecord(query=query,resultCount=0,status="failed",message=e.message ?: "Background scan failed")) }
                Result.failure()
            }
        }
    }
}
