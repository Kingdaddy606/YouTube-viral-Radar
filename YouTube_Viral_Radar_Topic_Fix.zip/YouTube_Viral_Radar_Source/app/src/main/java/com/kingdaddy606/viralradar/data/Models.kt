package com.kingdaddy606.viralradar.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.Json

data class DiscoveryResponse(val items: List<VideoDto> = emptyList(), val nextPageToken: String? = null, val quota: QuotaDto? = null)
data class QuotaDto(val searchUnitsEstimated: Int? = null, val note: String? = null)
data class VideoDto(
    @Json(name="videoId") val videoId: String,
    val channelId: String?, val title: String, val description: String?,
    @Json(name="thumbnailUrl") val thumbnailUrl: String?, val publishedAt: String?,
    val duration: String?, val viewCount: Long?, val likeCount: Long?, val commentCount: Long?,
    val channelTitle: String?, val subscriberCount: Long?, val score: ScoreDto?, val faceless: FacelessDto?,
    val youtubeUrl: String?
)
data class ScoreDto(val score: Int, val category: String, val note: String?)
data class FacelessDto(val label: String, val confidence: String, val reason: String)
data class ScanRequest(
    val query: String, val maxResults: Int = 25, val order: String = "date",
    val niche: String? = null, val age: String? = null, val subscriberCeiling: String? = null,
    val minimumViews: String? = null, val channelFormat: String? = null, val pageToken: String? = null
)

@Entity(tableName="saved_items")
data class SavedItem(@PrimaryKey val id: String, val kind: String, val title: String, val thumbnail: String?, val savedAt: Long = System.currentTimeMillis())
@Entity(tableName="cached_videos")
data class CachedVideo(@PrimaryKey val id: String, val title: String, val payload: String, val cachedAt: Long = System.currentTimeMillis())
@Entity(tableName="observations")
data class Observation(@PrimaryKey(autoGenerate=true) val id: Long = 0, val videoId: String, val views: Long, val observedAt: Long = System.currentTimeMillis())
