package com.kingdaddy606.viralradar.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.radarStore by preferencesDataStore("radar_settings")
class SettingsStore(private val context: Context) {
    private val endpointKey = stringPreferencesKey("worker_endpoint")
    private val autoScanKey = stringPreferencesKey("auto_scan")
    private val launchDiscoveryKey = stringPreferencesKey("launch_discovery")
    private val randomKey = stringPreferencesKey("random_selection")
    private val rapidGrowthKey = stringPreferencesKey("rapid_growth")
    private val minViewsKey = stringPreferencesKey("minimum_views")
    private val subscriberCeilingKey = stringPreferencesKey("subscriber_ceiling")
    private val ageFilterEnabledKey = stringPreferencesKey("age_filter_enabled")
    private val ageKey = stringPreferencesKey("video_age")
    private val videoLengthKey = stringPreferencesKey("video_length")

    val endpoint = context.radarStore.data.map { it[endpointKey] ?: "" }
    val autoScan = context.radarStore.data.map { it[autoScanKey] ?: "Off" }
    val launchDiscovery = context.radarStore.data.map { it[launchDiscoveryKey] ?: "true" }
    val randomSelection = context.radarStore.data.map { it[randomKey] ?: "true" }
    val rapidGrowth = context.radarStore.data.map { it[rapidGrowthKey] ?: "true" }
    val minimumViews = context.radarStore.data.map { it[minViewsKey] ?: "100000" }
    val subscriberCeiling = context.radarStore.data.map { it[subscriberCeilingKey] ?: "10000" }
    val ageFilterEnabled = context.radarStore.data.map { it[ageFilterEnabledKey] ?: "false" }
    val videoAge = context.radarStore.data.map { it[ageKey] ?: "7 days" }
    val videoLength = context.radarStore.data.map { it[videoLengthKey] ?: "Long-form (over 5 minutes)" }

    suspend fun setEndpoint(value: String) { require(value.isBlank() || value.startsWith("https://")); context.radarStore.edit { it[endpointKey] = value.trim() } }
    suspend fun setAutoScan(value: String) { require(value in listOf("Off", "Every 6 hours", "Every 12 hours", "Daily")); context.radarStore.edit { it[autoScanKey] = value } }
    suspend fun setLaunchDiscovery(value: Boolean) { context.radarStore.edit { it[launchDiscoveryKey] = value.toString() } }
    suspend fun setRandomSelection(value: Boolean) { context.radarStore.edit { it[randomKey] = value.toString() } }
    suspend fun setRapidGrowth(value: Boolean) { context.radarStore.edit { it[rapidGrowthKey] = value.toString() } }
    suspend fun setMinimumViews(value: String) { require(value.toLongOrNull() != null && value.toLong() >= 0); context.radarStore.edit { it[minViewsKey] = value } }
    suspend fun setSubscriberCeiling(value: String) { require(value.toLongOrNull() != null && value.toLong() >= 0); context.radarStore.edit { it[subscriberCeilingKey] = value } }
    suspend fun setAgeFilterEnabled(value: Boolean) { context.radarStore.edit { it[ageFilterEnabledKey] = value.toString() } }
    suspend fun setVideoAge(value: String) { context.radarStore.edit { it[ageKey] = value } }
    suspend fun setVideoLength(value: String) { require(value in listOf("All video lengths", "Shorts (up to 3 minutes)", "Long-form (over 5 minutes)")); context.radarStore.edit { it[videoLengthKey] = value } }
}
