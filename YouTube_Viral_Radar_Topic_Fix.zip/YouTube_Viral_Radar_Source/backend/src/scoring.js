export function viralScore({ views=0, subscribers=null, publishedAt=null, now=Date.now(), priorViews=null, priorObservedAt=null }) {
  const ratio = subscribers && subscribers > 0 ? views / subscribers : null;
  const ratioPts = ratio == null ? 0 : Math.min(40, Math.log10(1 + ratio) / Math.log10(101) * 40);
  const ageHours = publishedAt ? Math.max(1, (now - Date.parse(publishedAt)) / 3600000) : null;
  const velocity = ageHours ? views / ageHours : 0;
  const velocityPts = Math.min(25, Math.log10(1 + velocity) / 4 * 25);
  const viewPts = Math.min(20, Math.log10(1 + Math.max(0, views)) / 6 * 20);
  const freshnessPts = ageHours == null ? 0 : Math.max(0, 15 * (1 - Math.min(ageHours, 720) / 720));
  const score = Math.max(0, Math.min(100, Math.round(ratioPts + velocityPts + viewPts + freshnessPts)));
  const category = score < 30 ? 'low' : score < 50 ? 'monitor' : score < 70 ? 'promising' : score < 85 ? 'high' : 'exceptional';
  return { score, category, components: { viewsToSubscribers: Math.round(ratioPts), velocity: Math.round(velocityPts), views: Math.round(viewPts), freshness: Math.round(freshnessPts) }, ratio, velocity, note: 'Heuristic discovery score, not a probability or guarantee. Missing subscriber data contributes zero ratio points.' };
}

export function classifyFaceless(title='', description='') {
  const text = `${title} ${description}`.toLowerCase();
  const positive = ['animation','animated','documentary','voiceover','voice over','narration','explainer','screen recording','whiteboard','stock footage','storytelling','top 10','facts','tutorial','compilation'];
  const negative = ['my day','daily vlog','come with me','meet me','my life','personal update','face reveal','get ready with me'];
  const pos = positive.filter(x => text.includes(x)); const neg = negative.filter(x => text.includes(x));
  if (pos.length && !neg.length) return { label:'likely_faceless', confidence:'medium', reason:`Metadata signals: ${pos.slice(0,3).join(', ')}. Not visually verified.` };
  if (pos.length && neg.length) return { label:'possibly_faceless', confidence:'low', reason:'Mixed metadata signals. Not visually verified.' };
  if (neg.length) return { label:'likely_personality_led', confidence:'low', reason:`Personal-content signals: ${neg.slice(0,2).join(', ')}. Not visually verified.` };
  return { label:'unknown', confidence:'low', reason:'Insufficient metadata evidence; face presence cannot be determined.' };
}
