import { viralScore, classifyFaceless } from './scoring.js';
const json = (data, status=200) => new Response(JSON.stringify(data), { status, headers: { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', 'access-control-allow-origin':'*', 'access-control-allow-methods':'GET,POST,OPTIONS', 'access-control-allow-headers':'content-type' } });
const fail = (message, status=400) => json({ error: message }, status);
const now = () => new Date().toISOString();
async function youtube(path, params, env) {
  if (!env.YOUTUBE_API_KEY) throw new Error('YouTube API is not configured on the server.');
  const url = new URL(`https://www.googleapis.com/youtube/v3/${path}`);
  for (const [k,v] of Object.entries({...params, key:env.YOUTUBE_API_KEY})) if (v !== undefined && v !== null && v !== '') url.searchParams.set(k,String(v));
  const res = await fetch(url); const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `YouTube API error (${res.status})`);
  return data;
}
async function discover(body, env) {
  const q = String(body.query || body.keyword || '').trim(); if (!q) throw new Error('A search keyword is required.');
  const max = Math.min(25, Math.max(1, Number(body.maxResults || 10)));
  const search = await youtube('search', { part:'snippet', type:'video', q, order:body.order || 'date', maxResults:max, publishedAfter:body.publishedAfter }, env);
  const ids = (search.items || []).map(x=>x.id?.videoId).filter(Boolean);
  if (!ids.length) return { items:[], nextPageToken:search.nextPageToken || null, quota:{searchUnitsEstimated:100, note:'YouTube quota estimates are not authoritative.'} };
  const detail = await youtube('videos', { part:'snippet,statistics,contentDetails', id:ids.join(',') }, env);
  const channelIds = [...new Set((detail.items||[]).map(x=>x.snippet?.channelId).filter(Boolean))];
  const channelData = channelIds.length ? await youtube('channels', { part:'snippet,statistics', id:channelIds.join(',') }, env) : {items:[]};
  const channelMap = new Map((channelData.items||[]).map(c=>[c.id,c]));
  const items=[];
  for (const v of detail.items||[]) {
    const s=v.snippet||{}, st=v.statistics||{}, c=channelMap.get(s.channelId), cs=c?.statistics||{};
    const views=Number(st.viewCount||0), subs=cs.hiddenSubscriberCount ? null : (cs.subscriberCount == null ? null : Number(cs.subscriberCount));
    const score=viralScore({views,subscribers:subs,publishedAt:s.publishedAt}); const face=classifyFaceless(s.title,s.description);
    const row={ videoId:v.id, channelId:s.channelId, title:s.title, description:s.description||'', thumbnailUrl:s.thumbnails?.high?.url||s.thumbnails?.medium?.url||'', publishedAt:s.publishedAt, duration:v.contentDetails?.duration||null, viewCount:views, likeCount:st.likeCount==null?null:Number(st.likeCount), commentCount:st.commentCount==null?null:Number(st.commentCount), channelTitle:s.channelTitle, subscriberCount:subs, hiddenSubscriberCount:!!cs.hiddenSubscriberCount, score, faceless:face, youtubeUrl:`https://www.youtube.com/watch?v=${v.id}` };
    await env.DB.prepare(`INSERT INTO channels(channel_id,title,description,thumbnail_url,subscriber_count,video_count,view_count,hidden_subscriber_count,updated_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(channel_id) DO UPDATE SET title=excluded.title,description=excluded.description,thumbnail_url=excluded.thumbnail_url,subscriber_count=excluded.subscriber_count,video_count=excluded.video_count,view_count=excluded.view_count,hidden_subscriber_count=excluded.hidden_subscriber_count,updated_at=excluded.updated_at`).bind(s.channelId,s.channelTitle,c?.snippet?.description||null,c?.snippet?.thumbnails?.default?.url||null,subs,cs.videoCount?Number(cs.videoCount):null,cs.viewCount?Number(cs.viewCount):null,cs.hiddenSubscriberCount?1:0,now()).run();
    await env.DB.prepare(`INSERT INTO videos(video_id,channel_id,title,description,thumbnail_url,published_at,duration,view_count,like_count,comment_count,viral_score,score_reason,faceless_label,faceless_reason,first_seen_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(video_id) DO UPDATE SET title=excluded.title,description=excluded.description,thumbnail_url=excluded.thumbnail_url,view_count=excluded.view_count,like_count=excluded.like_count,comment_count=excluded.comment_count,viral_score=excluded.viral_score,score_reason=excluded.score_reason,faceless_label=excluded.faceless_label,faceless_reason=excluded.faceless_reason,updated_at=excluded.updated_at`).bind(v.id,s.channelId,s.title,s.description||null,row.thumbnailUrl,s.publishedAt,row.duration,views,row.likeCount,row.commentCount,score.score,score.note,face.label,face.reason,now(),now()).run();
    await env.DB.prepare('INSERT INTO video_observations(video_id,observed_at,view_count,like_count,comment_count) VALUES(?,?,?,?,?)').bind(v.id,now(),views,row.likeCount,row.commentCount).run(); items.push(row);
  }
  return { items, nextPageToken:search.nextPageToken||null, quota:{searchUnitsEstimated:100, note:'Estimate only; actual quota depends on API project configuration.'} };
}
export default { async fetch(request, env) {
  if (request.method==='OPTIONS') return json({ok:true});
  const url=new URL(request.url), p=url.pathname;
  try {
    if (p==='/api/health' && request.method==='GET') return json({ok:true,service:'YouTube Viral Radar API',time:now(),database:!!env.DB,youtubeConfigured:!!env.YOUTUBE_API_KEY});
    if (p==='/api/scan' && request.method==='POST') { let body; try { body=await request.json(); } catch { return fail('Invalid JSON body.'); } return json(await discover(body,env)); }
    if (p==='/api/discoveries' && request.method==='GET') {
      const limit=Math.min(100,Math.max(1,Number(url.searchParams.get('limit')||30)));
      const r=await env.DB.prepare(`SELECT v.*, c.title AS channel_title, c.subscriber_count AS subscriber_count FROM videos v LEFT JOIN channels c ON c.channel_id=v.channel_id ORDER BY v.viral_score DESC, v.published_at DESC LIMIT ?`).bind(limit).all();
      const items=(r.results||[]).map(v=>({
        videoId:v.video_id, channelId:v.channel_id, title:v.title, description:v.description,
        thumbnailUrl:v.thumbnail_url, publishedAt:v.published_at, duration:v.duration,
        viewCount:v.view_count, likeCount:v.like_count, commentCount:v.comment_count,
        channelTitle:v.channel_title, subscriberCount:v.subscriber_count,
        score:{score:Number(v.viral_score||0),category:Number(v.viral_score||0)>=85?'Exceptional':Number(v.viral_score||0)>=70?'High potential':Number(v.viral_score||0)>=50?'Promising':'Monitor',note:v.score_reason||''},
        faceless:{label:v.faceless_label||'unknown',confidence:'metadata-based',reason:v.faceless_reason||''},
        youtubeUrl:`https://www.youtube.com/watch?v=${v.video_id}`
      }));
      return json({items});
    }
    if (p.startsWith('/api/videos/') && p.endsWith('/history') && request.method==='GET') { const id=decodeURIComponent(p.split('/')[3]||''); const r=await env.DB.prepare('SELECT * FROM video_observations WHERE video_id=? ORDER BY observed_at ASC').bind(id).all(); return json({items:r.results||[]}); }
    if (p.startsWith('/api/videos/') && p.endsWith('/refresh') && request.method==='POST') { const id=decodeURIComponent(p.split('/')[3]||''); const d=await youtube('videos',{part:'snippet,statistics',id},env); const v=d.items?.[0]; if(!v)return fail('Video not found or unavailable.',404); const s=v.statistics||{}; await env.DB.prepare('UPDATE videos SET view_count=?,like_count=?,comment_count=?,updated_at=? WHERE video_id=?').bind(Number(s.viewCount||0),s.likeCount==null?null:Number(s.likeCount),s.commentCount==null?null:Number(s.commentCount),now(),id).run(); await env.DB.prepare('INSERT INTO video_observations(video_id,observed_at,view_count,like_count,comment_count) VALUES(?,?,?,?,?)').bind(id,now(),Number(s.viewCount||0),s.likeCount==null?null:Number(s.likeCount),s.commentCount==null?null:Number(s.commentCount)).run(); return json({ok:true,videoId:id,viewCount:Number(s.viewCount||0),observedAt:now()}); }
    if (p.startsWith('/api/videos/') && request.method==='GET') { const id=decodeURIComponent(p.split('/')[3]||''); const r=await env.DB.prepare('SELECT * FROM videos WHERE video_id=?').bind(id).first(); return r?json(r):fail('Video not found.',404); }
    if (p.startsWith('/api/channels/') && request.method==='GET') { const id=decodeURIComponent(p.split('/')[3]||''); const r=await env.DB.prepare('SELECT * FROM channels WHERE channel_id=?').bind(id).first(); return r?json(r):fail('Channel not found.',404); }
    if (p==='/api/history' && request.method==='GET') { const r=await env.DB.prepare('SELECT * FROM scan_history ORDER BY started_at DESC LIMIT 100').all(); return json({items:r.results||[]}); }
    if (p==='/api/quota' && request.method==='GET') return json({dailyDefaultUnits:10000,searchListCostEstimate:100,authoritative:false,note:'Check Google Cloud Console for the actual quota and usage.'});
    return fail('Not found.',404);
  } catch(e) { return json({error:e.message||'Unexpected server error.'},500); }
} };
