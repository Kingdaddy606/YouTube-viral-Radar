import test from 'node:test';
import assert from 'node:assert/strict';
import { viralScore, classifyFaceless } from '../src/scoring.js';
test('viral score is bounded and categorized',()=>{const x=viralScore({views:100000,subscribers:1000,publishedAt:new Date().toISOString()});assert.ok(x.score>=0&&x.score<=100);assert.ok(x.category);});
test('missing subscribers do not invent ratio',()=>{const x=viralScore({views:5000,subscribers:null});assert.equal(x.ratio,null);});
test('faceless detector explains metadata limitation',()=>{const x=classifyFaceless('Animated history explained','Narration and documentary');assert.equal(x.label,'likely_faceless');assert.match(x.reason,/Not visually verified/);});
test('unknown metadata remains unknown',()=>{assert.equal(classifyFaceless('Hello','Welcome to my channel').label,'unknown');});
